package Classe;

public class Produto {
        String nome;
        double preco;
        double desconto;
}
