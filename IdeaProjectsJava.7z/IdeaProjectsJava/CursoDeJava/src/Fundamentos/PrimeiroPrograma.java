//Primeiro programa.
package Fundamentos;

public class PrimeiroPrograma {
    //Tudo começa a partir de um MAIN!!!
    public static void main(String[] args) {
        System.out.println("Oi mundo 1"); //Uma
        System.out.println("Oi mundo 2");
    }
}
