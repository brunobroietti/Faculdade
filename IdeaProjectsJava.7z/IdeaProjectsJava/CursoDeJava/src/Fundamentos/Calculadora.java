package Fundamentos;

import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Digite um número: ");
        int n1 = in.nextInt();

        System.out.print("Digite outro número: ");
        int n2 = in.nextInt();

        System.out.print("Informa a operação: ");
        String op = in.nextLine();

        // Lógica
        double result = "+".equals(op) ? n1 + n2 : 0;
        result = "-".equals(op) ? n1 - n2 : result;
        result = "*".equals(op) ? n1 * n2 : result;
        result = "/".equals(op) ? n1 / n2 : result;

        System.out.printf("%.2f %s %.2f = %.2f", n1, op, n2, result);
        in.close();
    }
}
