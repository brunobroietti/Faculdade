package Fundamentos;

import java.util.Scanner;

public class Operador_Terniario {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Informe sua média: ");
        int media = in.nextInt();
        String resultadoFinal = media >= 70 ? "APROVADO" : "REPROVADO"; //Tem que colocar em ordem.
        System.out.println("O aluno foi "+resultadoFinal);
    }
}
