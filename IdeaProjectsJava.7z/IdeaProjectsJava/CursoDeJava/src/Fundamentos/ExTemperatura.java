//Cconversão de graus Fahrenheit pra graus Celsius
package Fundamentos;

public class ExTemperatura {
    public static void main(String[] args) {
        double resultado = (60 - 32)* 5/9;
        System.out.println("O valor em graus celsius é: "+resultado+"°C");
    }
}
