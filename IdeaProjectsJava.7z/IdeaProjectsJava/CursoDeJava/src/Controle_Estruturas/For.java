package Controle_Estruturas;

public class For {
    public static void main(String[] args) {
        int n1;

        for(n1 = 0; n1 <= 10; n1 = n1 +1) {      //   Como se fosse para n1 de 0 até 10 passo 1, divididos por ponto e vírgula.
            System.out.println("N1 = "+n1);      //   For é uma estrutura de repetição determinada. Sendo focada em uma quantidade
        }                                        // pré definida de repetições.
    }                                            //    O FOR é usado quando sabemos quantas vezes vamos repetir o laço, ou seja, posso
}                                                // repetir de 1 até 1000, até mesmo de forma infinita deixando-o indeterminado, mas
                                                 // para isso temos o While que por padrão e indeterminado.