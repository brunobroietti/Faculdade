package Facul.JogoCobrinha;

public class SnakeGame {
}
