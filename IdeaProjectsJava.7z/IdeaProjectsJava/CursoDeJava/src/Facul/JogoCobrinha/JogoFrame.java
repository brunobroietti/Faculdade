package Facul.JogoCobrinha;

import javax.swing.*;

public class JogoFrame extends JFrame {

    }

