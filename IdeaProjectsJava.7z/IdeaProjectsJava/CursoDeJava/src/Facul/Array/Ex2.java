package Facul.Array;

import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int vet1[] = new int[3];
        int vet2[] = new int[3];
        int vetArmazenar[] = new int[3];
        int i;

        for(i = 0; i < 3; i++) {
            System.out.println("Digite o "+(i + 1)+"° número: ");
            vet1[i] = in.nextInt();

        }
        for(i = 0; i < 3; i++) {
            System.out.println("Digite o "+(i + 1)+"° número do 2° vetor: ");
            vet2[i] = in.nextInt();
        }
        for(i = 0; i < 3; i++) {
            vetArmazenar[i] = vet1[i] - vet2[i];
            if(vetArmazenar[i] % 2 == 1) {
                System.out.println(vetArmazenar[i]);
            }
        }
    }
}
