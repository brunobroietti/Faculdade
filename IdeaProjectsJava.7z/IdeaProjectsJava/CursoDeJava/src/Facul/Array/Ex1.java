package Facul.Array;

import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n1[] = new int[4];
        int i;
        int soma = 0;

        for(i = 0; i < 10; i++) {
            System.out.println("Digite o "+(i + 1)+"° número: ");
            n1[i] = in.nextInt();
        }
        for(i = 0; i < 10; i++) {
            System.out.println("O números digitados: "+n1[i]);
            soma = soma + n1[i];
        }
        System.out.println();
        System.out.println("Soma: "+soma);
    }
}
