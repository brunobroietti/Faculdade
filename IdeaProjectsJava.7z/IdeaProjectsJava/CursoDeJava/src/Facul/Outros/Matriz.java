package Facul.Outros;

import java.util.Scanner;

public class Matriz {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int vetA[][] = new int[2][2];
        int vetB[][] = new int[2][2];
        int vetR[][] = new int[2][2];
        int i, j;

        System.out.println("Digite a matriz: ");
        for(i = 0; i < vetA.length; i++) {
            for(j = 0; j < vetA.length; j++) {
                vetA[i][j] = in.nextInt();
            }
        }
        System.out.println("Digite a segunda matriz: ");
        for(i = 0; i < vetB.length; i++) {
            for(j = 0; j < vetB.length; j++) {
                vetB[i][j] = in.nextInt();
                vetR[i][j] = vetA[i][j] * vetB[i][j];
            }
        }
        for(i = 0; i < vetR.length; i++) {
            for(j = 0; j < vetR.length; j++) {
                System.out.print(vetR[i][j] + " ");
            }
        }
    }
}
